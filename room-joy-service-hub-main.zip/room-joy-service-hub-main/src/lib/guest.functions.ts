import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const roomSchema = z.object({ number: z.string().trim().min(1).max(10) });
const authSchema = roomSchema.extend({ pin: z.string().regex(/^\d{4}$/) });

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function authRoom(number: string, pin: string) {
  const db = await admin();
  const { data } = await db.from("rooms").select("id, pin, guest_name").eq("number", number).maybeSingle();
  if (!data || !data.pin || data.pin !== pin) throw new Error("Senha incorreta");
  return { db, room: data };
}

export const checkRoom = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => roomSchema.parse(d))
  .handler(async ({ data }) => {
    const db = await admin();
    const { data: room } = await db.from("rooms").select("id, pin").eq("number", data.number).maybeSingle();
    return { exists: !!room, active: !!room?.pin };
  });

export const guestLogin = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => authSchema.parse(d))
  .handler(async ({ data }) => {
    try {
      const { room } = await authRoom(data.number, data.pin);
      return { ok: true as const, guestName: room.guest_name };
    } catch {
      return { ok: false as const, guestName: null };
    }
  });

export const listMyRequests = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => authSchema.parse(d))
  .handler(async ({ data }) => {
    const { db, room } = await authRoom(data.number, data.pin);
    const { data: rows } = await db
      .from("service_requests")
      .select("id, service, notes, status, created_at")
      .eq("room_id", room.id)
      .order("created_at", { ascending: false });
    return rows ?? [];
  });

export const createRequest = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    authSchema.extend({ service: z.string().min(1).max(80), notes: z.string().max(500).optional() }).parse(d),
  )
  .handler(async ({ data }) => {
    const { db, room } = await authRoom(data.number, data.pin);
    const { error } = await db
      .from("service_requests")
      .insert({ room_id: room.id, service: data.service, notes: data.notes || null });
    if (error) throw new Error("Não foi possível enviar");
    return { ok: true };
  });
