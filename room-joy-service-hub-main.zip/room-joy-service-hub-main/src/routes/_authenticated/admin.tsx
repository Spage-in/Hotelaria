import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { LogOut, Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Painel da Administração" },
      { name: "description", content: "Gerencie quartos, check-ins e pedidos dos hóspedes." },
      { property: "og:title", content: "Painel da Administração" },
      { property: "og:description", content: "Gerencie quartos, check-ins e pedidos dos hóspedes." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Admin,
});

type Room = { id: string; number: string; guest_name: string | null; pin: string | null };
type Req = { id: string; service: string; notes: string | null; status: string; created_at: string; rooms: { number: string } | null };

const NEXT: Record<string, string> = { pendente: "em_andamento", em_andamento: "concluido", concluido: "pendente" };
const LABEL: Record<string, string> = { pendente: "Pendente", em_andamento: "Em andamento", concluido: "Concluído" };

function Admin() {
  const nav = useNavigate();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [tab, setTab] = useState<"pedidos" | "quartos">("pedidos");
  const [rooms, setRooms] = useState<Room[]>([]);
  const [reqs, setReqs] = useState<Req[]>([]);
  const [filter, setFilter] = useState<"abertos" | "todos">("abertos");

  const load = useCallback(async () => {
    const [r, q] = await Promise.all([
      supabase.from("rooms").select("id, number, guest_name, pin").order("number"),
      supabase.from("service_requests").select("id, service, notes, status, created_at, rooms(number)").order("created_at", { ascending: false }).limit(300),
    ]);
    setRooms(r.data ?? []); setReqs((q.data as Req[]) ?? []);
  }, []);

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data }) => {
      const { data: role } = await supabase.from("user_roles").select("role").eq("user_id", data.user!.id).eq("role", "admin").maybeSingle();
      setIsAdmin(!!role);
      if (role) load();
    });
  }, [load]);

  useEffect(() => {
    if (!isAdmin) return;
    const id = setInterval(load, 10000);
    return () => clearInterval(id);
  }, [isAdmin, load]);

  async function logout() { await supabase.auth.signOut(); nav({ to: "/login" }); }

  if (isAdmin === null) return <main className="p-8 text-muted-foreground">Carregando…</main>;
  if (!isAdmin) return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 p-8 text-center">
      <p>Esta conta não tem acesso de administração.</p>
      <Button variant="secondary" onClick={logout}>Sair</Button>
    </main>
  );

  const shown = filter === "abertos" ? reqs.filter((r) => r.status !== "concluido") : reqs;

  return (
    <main className="mx-auto min-h-screen max-w-5xl bg-background px-6 py-8">
      <header className="mb-8 flex items-center justify-between">
        <h1 className="text-3xl font-semibold tracking-tight">Painel</h1>
        <Button variant="ghost" onClick={logout}><LogOut /> Sair</Button>
      </header>
      <div className="mb-6 inline-flex rounded-full bg-muted p-1">
        {(["pedidos", "quartos"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`rounded-full px-5 py-2 text-sm capitalize ${tab === t ? "bg-primary text-primary-foreground" : ""}`}>{t}</button>
        ))}
      </div>

      {tab === "pedidos" ? (
        <div className="space-y-3">
          <div className="flex gap-2">
            {(["abertos", "todos"] as const).map((f) => (
              <Button key={f} size="sm" variant={filter === f ? "default" : "secondary"} className="rounded-full capitalize" onClick={() => setFilter(f)}>{f}</Button>
            ))}
          </div>
          {!shown.length && <div className="rounded-3xl bg-muted p-8 text-center text-muted-foreground">Nenhum pedido.</div>}
          {shown.map((r) => (
            <div key={r.id} className="flex items-center justify-between gap-4 rounded-3xl bg-muted p-5">
              <div className="flex items-center gap-4">
                <div className="flex size-14 shrink-0 items-center justify-center rounded-2xl bg-background text-lg font-semibold">{r.rooms?.number}</div>
                <div>
                  <p className="font-medium">{r.service}</p>
                  {r.notes && <p className="text-sm text-muted-foreground">{r.notes}</p>}
                  <p className="text-xs text-muted-foreground">{new Date(r.created_at).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })}</p>
                </div>
              </div>
              <Button size="sm" variant={r.status === "concluido" ? "default" : "outline"} className="rounded-full"
                onClick={async () => { await supabase.from("service_requests").update({ status: NEXT[r.status] ?? "pendente" }).eq("id", r.id); load(); }}>
                {LABEL[r.status]}
              </Button>
            </div>
          ))}
        </div>
      ) : (
        <RoomsPanel rooms={rooms} reload={load} />
      )}
    </main>
  );
}

function RoomsPanel({ rooms, reload }: { rooms: Room[]; reload: () => void }) {
  const [newNumber, setNewNumber] = useState("");
  return (
    <div className="space-y-4">
      <form className="flex gap-2" onSubmit={async (e) => { e.preventDefault(); if (!newNumber.trim()) return; await supabase.from("rooms").insert({ number: newNumber.trim() }); setNewNumber(""); reload(); }}>
        <Input value={newNumber} onChange={(e) => setNewNumber(e.target.value)} placeholder="Novo quarto (ex: 301)" className="h-11 max-w-xs rounded-2xl border-0 bg-muted" />
        <Button className="h-11 rounded-2xl"><Plus /> Adicionar</Button>
      </form>
      <div className="grid gap-3 sm:grid-cols-2">
        {rooms.map((r) => <RoomCard key={r.id} room={r} reload={reload} />)}
      </div>
    </div>
  );
}

function RoomCard({ room, reload }: { room: Room; reload: () => void }) {
  const [name, setName] = useState(room.guest_name ?? "");
  const [pin, setPin] = useState(room.pin ?? "");
  const occupied = !!room.pin;
  return (
    <div className="space-y-3 rounded-3xl bg-muted p-5">
      <div className="flex items-center justify-between">
        <p className="text-2xl font-semibold">Quarto {room.number}</p>
        <span className={`rounded-full px-3 py-1 text-xs ${occupied ? "bg-primary text-primary-foreground" : "bg-background"}`}>{occupied ? "Ocupado" : "Livre"}</span>
      </div>
      <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome do hóspede" className="rounded-xl border-0 bg-background" />
      <Input value={pin} inputMode="numeric" maxLength={4} onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))} placeholder="4 últimos dígitos do telefone" className="rounded-xl border-0 bg-background" />
      <div className="flex gap-2">
        <Button size="sm" className="rounded-full" disabled={pin.length !== 4}
          onClick={async () => { await supabase.from("rooms").update({ guest_name: name || null, pin }).eq("id", room.id); reload(); }}>Check-in</Button>
        {occupied && (
          <Button size="sm" variant="secondary" className="rounded-full"
            onClick={async () => { await supabase.from("rooms").update({ guest_name: null, pin: null }).eq("id", room.id); await supabase.from("service_requests").delete().eq("room_id", room.id); setName(""); setPin(""); reload(); }}>Check-out</Button>
        )}
        <Button size="sm" variant="ghost" className="ml-auto rounded-full" aria-label="Excluir quarto"
          onClick={async () => { if (confirm(`Excluir quarto ${room.number}?`)) { await supabase.from("rooms").delete().eq("id", room.id); reload(); } }}><Trash2 /></Button>
      </div>
    </div>
  );
}
