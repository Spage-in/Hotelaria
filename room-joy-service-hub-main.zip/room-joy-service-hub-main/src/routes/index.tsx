import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Bath, BedDouble, Sparkles, Droplets, Package, Home, ClipboardList, ConciergeBell, Check, LogOut, Phone, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { checkRoom, guestLogin, listMyRequests, createRequest } from "@/lib/guest.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Serviço de Quarto — Solicite pelo celular" },
      { name: "description", content: "Peça toalhas, roupa de cama, limpeza e mais direto do seu quarto." },
      { property: "og:title", content: "Serviço de Quarto" },
      { property: "og:description", content: "Peça toalhas, roupa de cama, limpeza e mais direto do seu quarto." },
    ],
  }),
  component: Index,
});

const SERVICES = [
  { name: "Troca de toalhas", icon: Bath },
  { name: "Troca de roupa de cama", icon: BedDouble },
  { name: "Limpeza do quarto", icon: Sparkles },
  { name: "Produtos de banho", icon: Package },
  { name: "Água", icon: Droplets },
];

const STATUS: Record<string, string> = { pendente: "Pendente", em_andamento: "Em andamento", concluido: "Concluído" };

type Step = "room" | "confirm" | "pin" | "app";
type Tab = "inicio" | "pedidos" | "recepcao";
type Req = { id: string; service: string; notes: string | null; status: string; created_at: string };

function Index() {
  const [step, setStep] = useState<Step>("room");
  const [number, setNumber] = useState("");
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<Tab>("inicio");
  const [guest, setGuest] = useState<string | null>(null);

  useEffect(() => {
    const saved = sessionStorage.getItem("room-session");
    if (!saved) return;
    const s = JSON.parse(saved) as { number: string; pin: string };
    guestLogin({ data: s }).then((r) => {
      if (r.ok) { setNumber(s.number); setPin(s.pin); setGuest(r.guestName); setStep("app"); }
      else sessionStorage.removeItem("room-session");
    });
  }, []);

  async function submitRoom(e: React.FormEvent) {
    e.preventDefault(); setError("");
    if (!number.trim()) return;
    setLoading(true);
    const r = await checkRoom({ data: { number: number.trim() } }).finally(() => setLoading(false));
    if (!r.exists) return setError("Quarto não encontrado.");
    if (!r.active) return setError("Este quarto ainda não foi liberado pela recepção.");
    setStep("confirm");
  }

  async function submitPin(e: React.FormEvent) {
    e.preventDefault(); setError("");
    setLoading(true);
    const r = await guestLogin({ data: { number: number.trim(), pin } }).finally(() => setLoading(false));
    if (!r.ok) return setError("Senha incorreta.");
    sessionStorage.setItem("room-session", JSON.stringify({ number: number.trim(), pin }));
    setGuest(r.guestName); setStep("app");
  }

  function logout() {
    sessionStorage.removeItem("room-session");
    setNumber(""); setPin(""); setStep("room"); setTab("inicio");
  }

  if (step !== "app") {
    return (
      <main className="flex min-h-screen items-center justify-center bg-background px-6">
        <div className="w-full max-w-sm">
          <ConciergeBell className="mb-6 size-10" strokeWidth={1.5} />
          {step === "room" && (
            <form onSubmit={submitRoom} className="space-y-4">
              <h1 className="text-3xl font-semibold tracking-tight">Bem-vindo</h1>
              <p className="text-muted-foreground">Digite o número do seu quarto.</p>
              <Input inputMode="numeric" autoFocus value={number} onChange={(e) => setNumber(e.target.value)} placeholder="Ex: 101" className="h-14 rounded-2xl border-0 bg-muted text-center text-2xl" />
              {error && <p className="text-sm text-destructive">{error}</p>}
              <Button type="submit" disabled={loading} className="h-14 w-full rounded-2xl text-base">OK</Button>
            </form>
          )}
          {step === "confirm" && (
            <div className="space-y-4">
              <h1 className="text-3xl font-semibold tracking-tight">Confirme o quarto</h1>
              <div className="rounded-3xl bg-muted py-10 text-center">
                <p className="text-sm text-muted-foreground">Quarto</p>
                <p className="text-6xl font-semibold tracking-tight">{number}</p>
              </div>
              <p className="text-center text-muted-foreground">Este é o seu quarto?</p>
              <div className="grid grid-cols-2 gap-3">
                <Button variant="secondary" className="h-14 rounded-2xl text-base" onClick={() => setStep("room")}>Não</Button>
                <Button className="h-14 rounded-2xl text-base" onClick={() => setStep("pin")}>Sim, confirmar</Button>
              </div>
            </div>
          )}
          {step === "pin" && (
            <form onSubmit={submitPin} className="space-y-4">
              <h1 className="text-3xl font-semibold tracking-tight">Senha do quarto {number}</h1>
              <p className="text-muted-foreground">Digite os 4 últimos números do telefone informado no check-in.</p>
              <Input inputMode="numeric" type="password" maxLength={4} autoFocus value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))} placeholder="••••" className="h-14 rounded-2xl border-0 bg-muted text-center text-2xl tracking-[0.5em]" />
              {error && <p className="text-sm text-destructive">{error}</p>}
              <Button type="submit" disabled={loading || pin.length !== 4} className="h-14 w-full rounded-2xl text-base">Entrar</Button>
              <Button type="button" variant="ghost" className="w-full" onClick={() => { setPin(""); setStep("room"); }}>Voltar</Button>
            </form>
          )}
        </div>
      </main>
    );
  }

  const tabs: { id: Tab; label: string; icon: typeof Home }[] = [
    { id: "inicio", label: "Início", icon: Home },
    { id: "pedidos", label: "Pedidos", icon: ClipboardList },
    { id: "recepcao", label: "Recepção", icon: ConciergeBell },
  ];

  return (
    <main className="min-h-screen bg-background pb-32">
      <header className="mx-auto flex max-w-md items-center justify-between px-6 pt-8">
        <div>
          <p className="text-sm text-muted-foreground">Quarto {number}</p>
          <h1 className="text-2xl font-semibold tracking-tight">{guest ? `Olá, ${guest.split(" ")[0]}` : "Olá"}</h1>
        </div>
        <Button variant="ghost" size="icon" onClick={logout} aria-label="Sair"><LogOut /></Button>
      </header>
      <section className="mx-auto max-w-md px-6 pt-6">
        {tab === "inicio" && <Services number={number} pin={pin} onSent={() => setTab("pedidos")} />}
        {tab === "pedidos" && <Orders number={number} pin={pin} />}
        {tab === "recepcao" && <Reception number={number} pin={pin} />}
      </section>
      <nav className="fixed inset-x-0 bottom-6 flex justify-center px-6">
        <div className="flex gap-1 rounded-full bg-primary p-1.5">
          {tabs.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex w-24 flex-col items-center gap-0.5 rounded-full py-2 text-xs transition-colors ${tab === t.id ? "bg-primary-foreground text-primary" : "text-primary-foreground/70"}`}>
              <t.icon className="size-5" strokeWidth={1.75} />
              {t.label}
            </button>
          ))}
        </div>
      </nav>
    </main>
  );
}

function Services({ number, pin, onSent }: { number: string; pin: string; onSent: () => void }) {
  const [selected, setSelected] = useState<string | null>(null);
  const [notes, setNotes] = useState("");
  const [sending, setSending] = useState(false);

  async function send() {
    if (!selected) return;
    setSending(true);
    await createRequest({ data: { number, pin, service: selected, notes } }).finally(() => setSending(false));
    setSelected(null); setNotes(""); onSent();
  }

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Do que você precisa?</h2>
      <div className="grid grid-cols-2 gap-3">
        {SERVICES.map((s) => (
          <button key={s.name} onClick={() => setSelected(s.name)}
            className={`flex aspect-square flex-col justify-between rounded-3xl p-4 text-left transition-colors ${selected === s.name ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
            <s.icon className="size-7" strokeWidth={1.5} />
            <span className="font-medium leading-tight">{s.name}</span>
          </button>
        ))}
      </div>
      {selected && (
        <div className="space-y-3 rounded-3xl bg-muted p-4">
          <p className="font-medium">{selected}</p>
          <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Observação (opcional)" className="rounded-2xl border-0 bg-background" />
          <Button onClick={send} disabled={sending} className="h-12 w-full rounded-2xl">Enviar pedido</Button>
        </div>
      )}
    </div>
  );
}

function Orders({ number, pin }: { number: string; pin: string }) {
  const [rows, setRows] = useState<Req[] | null>(null);
  useEffect(() => {
    const load = () => listMyRequests({ data: { number, pin } }).then(setRows);
    load();
    const id = setInterval(load, 15000);
    return () => clearInterval(id);
  }, [number, pin]);

  if (!rows) return <p className="text-muted-foreground">Carregando…</p>;
  if (!rows.length) return <div className="rounded-3xl bg-muted p-8 text-center text-muted-foreground">Nenhum pedido ainda.</div>;
  return (
    <div className="space-y-3">
      <h2 className="text-lg font-semibold">Seus pedidos</h2>
      {rows.map((r) => (
        <div key={r.id} className="flex items-start justify-between gap-3 rounded-3xl bg-muted p-4">
          <div>
            <p className="font-medium">{r.service}</p>
            {r.notes && <p className="text-sm text-muted-foreground">{r.notes}</p>}
            <p className="mt-1 text-xs text-muted-foreground">{new Date(r.created_at).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })}</p>
          </div>
          <span className={`flex shrink-0 items-center gap-1 rounded-full px-3 py-1 text-xs ${r.status === "concluido" ? "bg-primary text-primary-foreground" : "bg-background"}`}>
            {r.status === "concluido" ? <Check className="size-3" /> : <Clock className="size-3" />}
            {STATUS[r.status] ?? r.status}
          </span>
        </div>
      ))}
    </div>
  );
}

function Reception({ number, pin }: { number: string; pin: string }) {
  const [msg, setMsg] = useState("");
  const [sent, setSent] = useState(false);
  async function send() {
    await createRequest({ data: { number, pin, service: "Mensagem para recepção", notes: msg } });
    setMsg(""); setSent(true);
  }
  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Recepção</h2>
      <div className="flex items-center gap-4 rounded-3xl bg-muted p-5">
        <Phone className="size-6" strokeWidth={1.5} />
        <div>
          <p className="font-medium">Ramal da recepção</p>
          <p className="text-sm text-muted-foreground">Disque 9 do telefone do quarto</p>
        </div>
      </div>
      <div className="space-y-3 rounded-3xl bg-muted p-4">
        <p className="font-medium">Enviar mensagem</p>
        <Textarea value={msg} onChange={(e) => { setMsg(e.target.value); setSent(false); }} placeholder="Como podemos ajudar?" className="rounded-2xl border-0 bg-background" />
        <Button onClick={send} disabled={!msg.trim()} className="h-12 w-full rounded-2xl">Enviar</Button>
        {sent && <p className="text-center text-sm text-muted-foreground">Mensagem enviada. Acompanhe em Pedidos.</p>}
      </div>
    </div>
  );
}
