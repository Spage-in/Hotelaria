import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Administração — Entrar" },
      { name: "description", content: "Acesso restrito à administração do hotel." },
      { property: "og:title", content: "Administração — Entrar" },
      { property: "og:description", content: "Acesso restrito à administração do hotel." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Login,
});

function Login() {
  const nav = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setMsg(""); setLoading(true);
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setLoading(false);
      if (error) return setMsg("E-mail ou senha inválidos.");
      nav({ to: "/admin" });
    } else {
      const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin + "/admin" } });
      setLoading(false);
      setMsg(error ? error.message : "Conta criada. Confirme pelo link enviado ao seu e-mail.");
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-6">
      <form onSubmit={submit} className="w-full max-w-sm space-y-4">
        <h1 className="text-3xl font-semibold tracking-tight">Administração</h1>
        <p className="text-muted-foreground">{mode === "in" ? "Entre para gerenciar quartos e pedidos." : "Criar conta de administrador."}</p>
        <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="E-mail" className="h-12 rounded-2xl border-0 bg-muted" />
        <Input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Senha" className="h-12 rounded-2xl border-0 bg-muted" />
        {msg && <p className="text-sm text-muted-foreground">{msg}</p>}
        <Button disabled={loading} className="h-12 w-full rounded-2xl">{mode === "in" ? "Entrar" : "Criar conta"}</Button>
        <Button type="button" variant="ghost" className="w-full" onClick={() => setMode(mode === "in" ? "up" : "in")}>
          {mode === "in" ? "Primeiro acesso? Criar conta" : "Já tenho conta"}
        </Button>
      </form>
    </main>
  );
}
